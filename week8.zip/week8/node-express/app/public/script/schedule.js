var hamburger = document.querySelector('#hamburger');
function showNav(){
document.querySelector('nav ul').classList.toggle('showNav');
}
hamburger.addEventListener('click',showNav);

const scheduleSection = document.querySelector('#schedule');
// Storing json datas URL
const localJsonFile = "data.json";

document.addEventListener('DOMContentLoaded', ()=>{
    fetch(localJsonFile)
    .then(response => response.json())
    .then (responseData =>{ console.log(responseData);
    
    for (item of responseData){
        const schedule = document.createElement('article');
        const imageElement = document.createElement('img');
        const levelhead4 = document.createElement('h4');
        const yogastyle = document.createElement('p');
        const time = document.createElement('p');
        const focus = document.createElement('p');
        const healthBenifits = document.createElement('p');
        const skillLevel = document.createElement('p');
        let sectionElement = scheduleSection;
        

        sectionElement.appendChild(schedule)
        imageElement.src = item.imageURL;
        imageElement.alt = item.alt;
        schedule.appendChild(imageElement);
    
        imageElement.style.width = '100%'

        levelhead4.textContent =` Yoga Style: ${item.style}`;
        schedule.appendChild(levelhead4)

        time.textContent =`Time: ${item.time}`;
        schedule.appendChild(time)
        
        focus.textContent =`Focus: ${item.focus}`;
        schedule.appendChild(focus)

        healthBenifits.textContent =`Health Benifits: ${item.benefits}`;
        schedule.appendChild(healthBenifits)

        skillLevel.textContent =`Skill Level: ${item.level}`;
        schedule.appendChild(skillLevel)

        schedule.setAttribute('class','services');
    }})
    .catch(error => console.error("Error fetching JSON data:", error));
})
    
        

        



    
