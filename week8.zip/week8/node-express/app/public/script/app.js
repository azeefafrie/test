var myVariable = "Welcome to CMP-4011 Web-Based Programming";
console.log(myVariable);


var myVariable = "Welcome to CMP-4011 Web-Based Programming Module";
console.log(myVariable);

let letVariable = "This is a let variable";
console.log(letVariable);

 letVariable = "This is an updated let variable value";
console.log(letVariable);

const constVariable = "This is a const variable";
console.log(constVariable);

/*constVariable = "This is an updated const variable value";
console.log(constVariable);*/

for (i=0; i<5; i++){
    console.log(myVariable +" "+ i);
    }

let myDate = new Date();
let todaysDate = myDate.toDateString();

let e=document.querySelector('.mypara');

e.innerHTML = 'Today is ' + todaysDate;
e.setAttribute('class', 'dateStyle');



let newPara = document.createElement('p');
newPara.textContent = "Hello, This is a new Paragraph!";
let sectionElement = document.querySelector('section');
sectionElement.parentNode.insertBefore(newPara, sectionElement);

newPara.setAttribute('class', 'dateStyle');


let newList = document.createElement('li');
newList.textContent = "Helps improve blood circulation";
let benefits = document.querySelector("main ul");
benefits.insertBefore(newList, benefits.lastElementChild);

benefits.removeChild(benefits.lastElementChild)

var hamburger = document.querySelector('#hamburger');
function showNav(){
document.querySelector('nav ul').classList.toggle('showNav');
}
hamburger.addEventListener('click',showNav);


/*hamburger.addEventListener('click', function() {
    document.querySelector('nav ul').classList.toggle('showNav');
});*/


