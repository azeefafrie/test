var hamburger = document.querySelector('#hamburger');
function showNav(){
document.querySelector('nav ul').classList.toggle('showNav');
}
hamburger.addEventListener('click',showNav);


/*hamburger.addEventListener('click', function() {
    document.querySelector('nav ul').classList.toggle('showNav');
});*/

let myForm = document.querySelector('form');
let myName = document.querySelector('#name');
let myEmail = document.querySelector('#email');
let message = document.querySelector('.message');

myForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    message.textContent=`Hi ${myName.value}, your message has been received, we will contact you at ${myEmail.value}`;
    });